# Fish Randomizer / Damaged Creature Morpher

Combat in Subnautica. It's so unsatisfying.

This mod seeks to change that by randomly transforming any creature damaged that doesn't immediately die into a totally random creature with the same amount of remaining health. Ever wish that Rabbit Ray you hit would spin back around and devour you with vengeance? This mod's got you covered.

This mod only applies to damage dealt with the knife.

Please save before enabling this mod- and note that I accept no responsibility for rogue leviathans created in this manner.

Please also note that Sea Emperors created in this manner are intelligent beings and deserve names and care.